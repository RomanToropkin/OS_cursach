#include <fcntl.h>
#include <sys/types.h>
#include <sys/msg.h>
#include <sys/ipc.h>
#include <stdio.h>
#include <unistd.h>
#include <iostream>
#include <string>
#include <string.h>

using namespace std;

int main(int argc, char** argv) {
    printf("Терминал пользователя запущен\n");
    int quantity=0;
    key_t ipckey1;
    int queue1_id;
    
    ipckey1 = ftok("/home/nika/Рабочий стол/AZS/send", 42);//Создаем ключ для первой очереди
    queue1_id = msgget(ipckey1, IPC_CREAT | 0644);//Создаем первую очередь
    
    return 0;
}

