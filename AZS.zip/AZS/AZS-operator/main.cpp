#include <fcntl.h>
#include <sys/types.h>
#include <sys/msg.h>
#include <sys/ipc.h>
#include <stdio.h>
#include <unistd.h>
#include <iostream>
#include <string>
#include <string.h>

using namespace std;

bool Response();
int prompt_menu_item();

int main(int argc, char** argv)
{
    printf("Терминал оператора-кассира запущен\n");
    int quantity=0;
    key_t ipckey1;
    key_t ipckey2;
    int queue1_id;
    int queue2_id;
    
    ipckey1 = ftok("/home/nika/Рабочий стол/AZS/send", 42);//Создаем ключ для первой очереди
    ipckey2 = ftok("/home/nika/Рабочий стол/AZS/send", 43);//Создаем ключ для второй очереди
    queue1_id = msgget(ipckey1, IPC_CREAT | 0644);//Создаем первую очередь
    queue2_id = msgget(ipckey2, IPC_CREAT | 0644);//Создаем вторую очередь

    //Работа с меню
    int variant = prompt_menu_item();
    switch (variant) {
        case 1:
            cout << "Определить состояние хранилища топлива А-92" << endl;
            break;
        case 2:
            cout << "Определить состояние хранилища топлива А-95" << endl;
            break;
        case 3:
            cout << "Определить параметры хранилища топлива А-92" << endl;
            break;
        case 4:
            cout << "Определить параметры хранилища топлива А-95" << endl;
            break;
        case 5:
            cout << "Определить состояние первой колонки" << endl;
            break;
        case 6:
            cout << "Определить состояние второй колонки" << endl;
            break;
        case 7:
            cout << "Определить параметры первой колонки" << endl;
            break;
        case 8:
            cout << "Определить параметры второй колонки" << endl;
            break;
        case 9:
            cout << "Отпустить топливо пользователю через первую колонку" << endl;
            break;
        case 10:
            cout << "Отпустить топливо пользователю через вторую колонку" << endl;
            break;
        default:
            cerr << "Вы выбрали неверный вариант" << endl;
            exit(EXIT_FAILURE);
    }
    
//    while(quantity<10)
//    {
//        printf("Введите сообщение для отправки на сервер:  ");
//        char chr[12] ;
//        cin.getline(chr,12);
//        printf("Запрос серверу: \"%s\" отправлен\n", chr);
//        msgsnd(mq_id, &chr, sizeof(chr), 0);
//        while(Response());
//        quantity++;
//    }
}

int prompt_menu_item()
{
    //Вариант меню
    int variant;
    cout << "Выберите действие, которое хотите сделать\n" << endl;
    cout << "1. Определить состояние хранилища топлива А-92\n"
         << "2. Определить состояние хранилища топлива А-95\n"
         << "3. Определить параметры хранилища топлива А-92\n"
         << "4. Определить параметры хранилища топлива А-95\n"
         << "5. Определить состояние первой колонки\n"
         << "6. Определить состояние второй колонки\n"
         << "7. Определить параметры первой колонки\n"
         << "8. Определить параметры второй колонки\n"
         << "9. Отпустить топливо пользователю через первую колонку\n"
         << "10. Отпустить топливо пользователю через вторую колонку\n" << endl;
    cout << ">>> ";
    cin >> variant;
    return variant;
}

bool Response()
{
//    key_t ipckey;
//    int mq_id;
//    char mymsg[BUFSIZ] ;
//    int received;
//    char str[100];
//
//    ipckey = ftok("/home/nika/Рабочий стол/laba9/send", 43);
//    mq_id = msgget(ipckey, 0);
//
//    memset(mymsg, 0, sizeof(mymsg));
//    received = msgrcv(mq_id, &mymsg, sizeof(mymsg), 0, 1);
//    printf("Ответ от сервера: \"%s\" получен\n\n", mymsg);
//
//    auto temp=std::to_string(getpid());
//    char const *pchar = temp.c_str();
//    memset(&str[0], 0, sizeof(str));
//    strcat(str,"echo ");
//    strcat(str,mymsg);
//    strcat(str," >> client_msgs.");
//    strcat(str,pchar );
//    system(str);
//    return false;
}

