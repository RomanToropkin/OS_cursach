#ifndef TANK_H
#define TANK_H

#include "global.h"

#define ERROR_NO_THIS_TYPE  0x000000FF
#define ERROR_NOT_ENOUGH    0x0000FFFF
#define SUCCESS_HANDLING    0x00FFFFFF

/** Тип топлива */
enum EFuel : int
{
    /** Солярка */
    Diesel = 1 << 0,
    /** Газ */
    GAS = 1 << 1,
    /** 92 бензин */
    AI_92 = 1 << 2,
    /** 95 бензин */
    AI_95 = 1 << 3,
    /** 98 бензин */
    AI_98 = 1 << 4,
    /** 100 бензин */
    AI_100 = 1 << 5,
    /** Граница битов */
    COUNT = 1 << 6
};

std::string EFuelToString(const EFuel& fuelType);

EFuel StringToEFuel(const std::string& sType);

struct TankPacket
{
    /** Тип топлива */
    EFuel m_fuelType;
    /** Название канала колонки */
    char m_pipeName[255];
    union
    {
        /** Запрошено топлива */
        size_t m_nRequested;
        struct
        {
            /** Осталось топлива */
            int m_nLeft;
            /** Успешно ли ? */
            int n_isSuccess;
        };
    };
};

#endif // TANK_H
