#ifndef GASSTATION_H
#define GASSTATION_H

#include "global.h"
#include "tank.h"

/** Канал хранилища */
#define STORAGE_PIPE_PATH               "/tmp/storage__pipe"

/** Канал инициализации колонки */
#define STATION_INIT_PIPE               "/tmp/station_init__pipe"

/** Файл для Advisory блокировки (Хранилище) */
#define STORAGE_SADVISORY_LOCK_FILE     "/tmp/station__advisory_st"

/** Файл для Advisory блокировки (Оператор) */
#define OPERATOR_ADVISORY_LOCK_FILE     "/tmp/station__advisory_op"

/** Канал получения отправки ответов от хранилища оператору */
#define OPERATOR_TO_STORAGE_MEDIATOR    "/tmp/storage__operator"


/** Пакет взаимодействия с колонкой */
struct StationPacket
{
    /** Тип топлива */
    EFuel m_eFuelType;

    /** Номер колонки */
    size_t m_nNumber;

    union
    {
        /** Количество топлива */
        size_t m_nFuelAmount;

        struct
        {
            /** Осталось топлива */
            int m_nLeft;

            /** Успешно ли ? */
            int n_isSuccess;
        };
    };
};

/** Пакет инициализации колонки */
struct StationInitPacket
{
    /** Виды топлива */
    int m_nFuelTypeFlags;

    /** Номер колонки */
    size_t m_nNumber;
};

/** Класс бензоколонка */
class GasStation
{
private:
    /** Флаги поддерживаемого топлива */
    int m_fuelTypeFlags;

    /** Номер колонки */
    size_t m_nNumber;

    /** Имя канала для связи с оператором */
    std::string m_sPipeName;

    /** Имя канала для связи с хранилищем */
    std::string m_sStoragePipeName;

    /** Поток работы с хранилищем */
    pthread_t m_thread;

    /** Очередь к колонке */
    std::queue<StationPacket> m_queue;

    /** Мьютекс для работы с очередью */
    pthread_mutex_t m_queueLock;

    /** Дескриптор поступления заявки в очередь */
    int m_fdEvent;

    /** Дескриптор файла для Advisory блокировки между процессами колонки на отправку запросов в хранилище */
    int m_storageAdvisoryBlock;

    /** Дескриптор файла для Advisory блокировки между процессами колонки на отправку ответов оператору */
    int m_operatorAdvisoryBlock;

    /** Флаг работы */
    bool m_isWork;


private:
    /** Обработчик потока
     *  1. Берет очередной элемент из очереди
     *  2. Отправляет запрос в хранилище и ждет ответа
     *  3. Формирует и отправляет ответ оператору
     **/
    static void* Rountine(void *arg);

public:
    GasStation();

    /** Запустить колонку */
    void Start();

    ~GasStation();
};

#endif // GASSTATION_H
