#include "tank.h"

std::string EFuelToString(const EFuel& fuelType)
{
    switch (fuelType)
    {
    case EFuel::Diesel:
        return "Дизель";
    case EFuel::GAS:
        return "Газ";
    case EFuel::AI_92:
        return "АИ-92";
    case EFuel::AI_95:
        return "АИ-95";
    case EFuel::AI_98:
        return "АИ-98";
    case EFuel::AI_100:
        return "АИ-100";
    default:
        return std::string();
    }
}

EFuel StringToEFuel(const std::string& sType)
{
    if(sType == "Дизель")
    {
        return EFuel::Diesel;
    }
    if(sType == "Газ")
    {
        return EFuel::GAS;
    }
    if(sType == "АИ-92")
    {
        return EFuel::AI_92;
    }
    if(sType == "АИ-95")
    {
        return EFuel::AI_95;
    }
    if(sType == "АИ-98")
    {
        return EFuel::AI_98;
    }
    if(sType == "АИ-100")
    {
        return EFuel::AI_100;
    }

    throw std::exception();
}
