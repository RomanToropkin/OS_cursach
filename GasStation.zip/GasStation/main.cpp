#include "gasstation.h"

int main()
{
    GasStation station;

    station.Start();
}
