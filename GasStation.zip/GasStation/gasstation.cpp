#include "gasstation.h"

GasStation::GasStation()
{
    m_isWork = true;

    pthread_mutex_init(&m_queueLock, nullptr);
    m_fdEvent = eventfd(0, 0);
}

void GasStation::Start()
{   
    /** Отправка нового PID оператору */
    pid_t pid = getpid();
    std::string sPid = std::to_string(pid);
    int fd_init = open(STATION_INIT_PIPE, O_WRONLY);
    ssize_t nCount = write(fd_init, &pid, sizeof(pid_t));
    close(fd_init);

    /** Создаем канал для общения с оператором */
    m_sPipeName = "/tmp/station__pipe" + sPid;
    mkfifo(m_sPipeName.c_str(), 0666);

    /** Создаем канал для приема сообщений от хранилища */
    m_sStoragePipeName = "/tmp/station__pipe" + sPid + "__s";
    mkfifo(m_sStoragePipeName.c_str(), 0666);

    /** Открытие файла для межпроцессорной блокировки */
    m_storageAdvisoryBlock = open(STORAGE_SADVISORY_LOCK_FILE, O_CREAT);

    /** Открытие файла для межпроцессорной блокировки */
    m_operatorAdvisoryBlock = open(OPERATOR_ADVISORY_LOCK_FILE, O_CREAT);

    /** Прием типов поддерживаемого топлива и номера колонки */
    StationInitPacket initPacket;
    int fd = open(m_sPipeName.c_str(), O_RDONLY);
    nCount = read(fd, &initPacket, sizeof(StationInitPacket));
    close(fd);
    if(nCount != sizeof(StationInitPacket))
    {
        std::cout << "Ошибка инициализации колонки" << std::endl;
        return;
    }

    std::cout << "Колонка №" << initPacket.m_nNumber + 1 << std::endl;

    m_fuelTypeFlags = initPacket.m_nFuelTypeFlags;
    m_nNumber = initPacket.m_nNumber;
    for(int i = 1;i <= EFuel::COUNT;i <<= 1)
    {
        if(m_fuelTypeFlags & i)
        {
            std::cout << "Поддерживает " << EFuelToString(EFuel(i)) << std::endl;
        }
    }

    /** Запуск нового потока для обработки очереди */
    pthread_create(&m_thread, nullptr, GasStation::Rountine, this);

    /** Прием запросов от оператора */
    while(true)
    {
        StationPacket packet;
        int fd = open(m_sPipeName.c_str(), O_RDONLY);
        ssize_t nCount = read(fd, &packet, sizeof(StationPacket));
        close(fd);

        if(nCount != sizeof(StationPacket))
        {
            /** Запрос на модификацию */
            if(nCount == sizeof(StationInitPacket))
            {
                m_fuelTypeFlags = static_cast<int>(packet.m_eFuelType);
                std::cout << "Флаги типов топлива изменены" << std::endl;
                for(int i = 1;i <= EFuel::COUNT;i <<= 1)
                {
                    if(m_fuelTypeFlags & i)
                    {
                        std::cout << "Поддерживает " << EFuelToString(EFuel(i)) << std::endl;
                    }
                }
            }
            continue;
        }

        /** Команда на выход */
        if(packet.m_nFuelAmount == ULONG_MAX)
        {
            break;
        }

        pthread_mutex_lock(&m_queueLock);

        m_queue.push(packet);

        pthread_mutex_unlock(&m_queueLock);

        uint64_t value = 1;
        write(m_fdEvent, &value, sizeof(value));
    }
}


void* GasStation::Rountine(void *arg)
{
    GasStation* station = reinterpret_cast<GasStation *>(arg);

    while(station->m_isWork)
    {
        pthread_mutex_lock(&station->m_queueLock);
        /** Ожидание поступления завяки */
        while(station->m_queue.empty() && station->m_isWork)
        {
            pthread_mutex_unlock(&station->m_queueLock);

            uint64_t value;
            read(station->m_fdEvent, &value, sizeof(value));

            pthread_mutex_lock(&station->m_queueLock);
        }

        /** Достаем завяку */
        StationPacket packet = station->m_queue.front();
        station->m_queue.pop();

        pthread_mutex_unlock(&station->m_queueLock);

        /** Формируем заявку в хранилище */
        TankPacket send_packet;
        send_packet.m_fuelType = packet.m_eFuelType;
        send_packet.m_nRequested = packet.m_nFuelAmount;
        strcpy(send_packet.m_pipeName, station->m_sStoragePipeName.c_str());

        std::cout << "Обрабатывается заявка на " << packet.m_nFuelAmount << " единиц топлива " << EFuelToString(packet.m_eFuelType) << std::endl;

        /** Отправляем заявку в хранилище на получение топлива */
        flock(station->m_storageAdvisoryBlock, LOCK_EX);
        int storage_wfd = open(STORAGE_PIPE_PATH, O_WRONLY);
        write(storage_wfd, &send_packet, sizeof(TankPacket));
        close(storage_wfd);
        flock(station->m_storageAdvisoryBlock, LOCK_UN);


        TankPacket recv_packet;
        /** Ждем ответ от хранилища */
        int storage_rfd = open(station->m_sStoragePipeName.c_str(), O_RDONLY);
        read(storage_rfd, &recv_packet, sizeof(TankPacket));
        close(storage_rfd);

        switch (recv_packet.n_isSuccess)
        {
            case ERROR_NOT_ENOUGH:
                std::cout << "В хранилище недостаточно топлива" << std::endl;
                break;
            case ERROR_NO_THIS_TYPE:
                std::cout << "Ни в одном хранилище нет топлива типа " << EFuelToString(recv_packet.m_fuelType) << std::endl;
                break;
            case SUCCESS_HANDLING:
                std::cout << "Успешно выкачано. В хранилище потенциально осталось " << recv_packet.m_nLeft << " единиц" << std::endl;
                break;
        }

        /** Формируем ответ для оператора */
        StationPacket op_packet;
        op_packet.m_eFuelType = recv_packet.m_fuelType;
        op_packet.m_nLeft = recv_packet.m_nLeft;
        op_packet.n_isSuccess = recv_packet.n_isSuccess;
        op_packet.m_nNumber = station->m_nNumber;

        /** Отправляем ответ от хранилища оператору */
        flock(station->m_operatorAdvisoryBlock, LOCK_EX);
        int os_wfd = open(OPERATOR_TO_STORAGE_MEDIATOR, O_WRONLY);
        write(os_wfd, &op_packet, sizeof(StationPacket));
        close(os_wfd);
        flock(station->m_operatorAdvisoryBlock, LOCK_UN);
    }

    return nullptr;
}

GasStation::~GasStation()
{
    m_isWork = false;

    uint64_t value = 1;
    write(m_fdEvent, &value, sizeof(value));

    pthread_join(m_thread, nullptr);

    pthread_mutex_destroy(&m_queueLock);
    close(m_fdEvent);

    close(m_storageAdvisoryBlock);
    close(m_operatorAdvisoryBlock);
}
