#include "vehicle.h"

EFuel StringToEFuel(const std::string& sType)
{
    if(sType == "Дизель")
    {
        return EFuel::Diesel;
    }
    if(sType == "Газ")
    {
        return EFuel::GAS;
    }
    if(sType == "АИ-92")
    {
        return EFuel::AI_92;
    }
    if(sType == "АИ-95")
    {
        return EFuel::AI_95;
    }
    if(sType == "АИ-98")
    {
        return EFuel::AI_98;
    }
    if(sType == "АИ-100")
    {
        return EFuel::AI_100;
    }

    throw std::exception();
}

Vehicle::Vehicle()
{
    /** Открытие файла для межпроцессорной блокировки */
    m_operatorAdvisoryBlock = open(OPERATOR_ADVISORY_LOCK_FILE, O_CREAT);
}

void Vehicle::FillUp(size_t nAmount, EFuel fuelType)
{
    VehiclePacket packet;
    packet.m_eFuelType = fuelType;
    packet.m_nAmount = nAmount;

    /** Отправляем пакет */
    flock(m_operatorAdvisoryBlock, LOCK_EX);
    int fd = open(OPERATOR_PIPE_PATH, O_WRONLY);
    write(fd, &packet, sizeof(VehiclePacket));
    close(fd);
    flock(m_operatorAdvisoryBlock, LOCK_UN);
}
