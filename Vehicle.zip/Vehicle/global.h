#ifndef GLOBAL_H
#define GLOBAL_H

#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/fcntl.h>
#include <sys/wait.h>
#include <stdio.h>
#include <sys/eventfd.h>
#include <pthread.h>
#include <sys/file.h>


#include <vector>
#include <string.h>
#include <string>
#include <algorithm>
#include <iostream>
#include <iomanip>
#include <climits>
#include <sstream>

#include <functional>
#include <queue>

#endif // GLOBAL_H
