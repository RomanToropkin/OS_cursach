#ifndef VEHICLE_H
#define VEHICLE_H

#include "global.h"

/** Файл для Advisory блокировки (Оператор) */
#define OPERATOR_ADVISORY_LOCK_FILE  "/tmp/station__advisory_op"

/** Канал отправки оператору */
#define OPERATOR_PIPE_PATH           "/tmp/storage__operator"

/** Тип топлива */
enum EFuel : int
{
    /** Солярка */
    Diesel = 1 << 0,
    /** Газ */
    GAS = 1 << 1,
    /** 92 бензин */
    AI_92 = 1 << 2,
    /** 95 бензин */
    AI_95 = 1 << 3,
    /** 98 бензин */
    AI_98 = 1 << 4,
    /** 100 бензин */
    AI_100 = 1 << 5
};

/** Значение мусора в пакете */
#define BUMP_VALUE 0xFFFFFFFFFFFFFFFF

/** Пакет отправляемые оператору */
struct VehiclePacket
{
    /** Тип запрашиваемого топлива */
    EFuel m_eFuelType;

    /** Мусор - для веса пакету (Так как StationPacket весит 12 байт) */
    size_t m_nBump;

    /** Количество запрашиваемого топлива */
    size_t m_nAmount;

    /**************************************/
    VehiclePacket() : m_nBump(BUMP_VALUE) {}
};

EFuel StringToEFuel(const std::string& sType);

class Vehicle
{
private:
    /*
     *
     *
     *
     *
     * ЗДЕСЬ ТИПА ПОЛЯ ОПИСЫВАЮЩИЕ ТАЧКУ
     *
     *
     *
     *
     */
private:
    /** Дескриптор файла для Advisory блокировки между процессами колонки и машины (Так как они пишут в один канал оператора) */
    int m_operatorAdvisoryBlock;

public:
    Vehicle();

    /** Заправиться */
    void FillUp(size_t nAmount, EFuel fuelType);
};

#endif // VEHICLE_H
