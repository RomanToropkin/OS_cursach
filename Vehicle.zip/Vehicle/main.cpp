#include "vehicle.h"

int main()
{
    Vehicle vehicle;

    while (true)
    {
        std::string sFuelType;
        std::string sAmount;

        size_t nAmount;
        EFuel  eFuelType;

        std::cout << "Машина прибыла на АЗС" << std::endl;
        std::cout << "Введите количество топлива, необходимое залить в бак" << std::endl;
        std::cin >> sAmount;

        std::cout << "Введите вид топлива (АИ-92, АИ-95, Дизель, Газ)" << std::endl;
        std::cin >> sFuelType;

        try
        {
            nAmount = std::stoul(sAmount);
            eFuelType = StringToEFuel(sFuelType);
        }
        catch(std::exception)
        {
            std::cout << "Некорректно введены данные" << std::endl;
            continue;
        }

        vehicle.FillUp(nAmount, eFuelType);

        system("clear");
    }
}
