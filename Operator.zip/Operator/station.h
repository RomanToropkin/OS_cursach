#ifndef STATION_H
#define STATION_H

#include "global.h"

#define STATION_INIT_PIPE "/tmp/station_init__pipe"

/** Тип топлива */
enum EFuel : int
{
    /** Солярка */
    Diesel = 1 << 0,
    /** Газ */
    GAS = 1 << 1,
    /** 92 бензин */
    AI_92 = 1 << 2,
    /** 95 бензин */
    AI_95 = 1 << 3,
    /** 98 бензин */
    AI_98 = 1 << 4,
    /** 100 бензин */
    AI_100 = 1 << 5,
    /** Неопределенный */
    UNDEFINED = 0,
};

/** Пакет взаимодействия с колонкой */
struct StationPacket
{
    /** Тип топлива */
    EFuel m_eFuelType;

    /** Номер колонки */
    size_t m_nNumber;

    union
    {
        /** Количество топлива */
        size_t m_nFuelAmount;

        struct
        {
            /** Осталось топлива */
            int m_nLeft;

            /** Успешно ли ? */
            int n_isSuccess;
        };
    };
};

/** Пакет инициализации колонки */
struct StationInitPacket
{
    /** Виды топлива */
    int m_nFuelTypeFlags;

    /** Номер колонки */
    size_t m_nNumber;
};

class Station
{
private:
    /** ID процесса */
    pid_t m_pid;

    /** Типы поддерживаемого топлива */
    int m_fuelFlag;

    /** Имя канала Колонка читает - Оператор пишет*/
    std::string m_sPipeName;

    /** Количество машин в очереди */
    size_t nQueueCount;

public:
    /** Путь до исполняемого файла (Терминал колонки) */
    static std::string ms_sStationTerminalPath;

public:
    std::string GetPipeName() const;

public:
    Station();

    /** Запустить новую колонку */
    void Start(int nFlags);

    /** Изменить набор флагов определяющих тип топлива */
    void SetFlags(int nFlags);

    /** Получить r-value для количества машин в очереди у колонки */
    size_t& GetQueueCount();

    /** Получить флаги типов топлива */
    int GetFlags() const;
};

#endif // STATION_H
