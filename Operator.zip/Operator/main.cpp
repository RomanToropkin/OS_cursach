#include "operator.h"


int main()
{
    Operator oper;

    oper.Start();

    //oper.ExecuteCommand("start_storage");
    //oper.ExecuteCommand("fake_stations");

    while(true)
    {
        std::string sCommand;
        std::getline(std::cin, sCommand);

        oper.ExecuteCommand(sCommand);
    }

    return 0;
}
