#include "station.h"

std::string Station::ms_sStationTerminalPath;

Station::Station()
{
    nQueueCount = 0;
}

std::string Station::GetPipeName() const
{
    return this->m_sPipeName;
}

size_t& Station::GetQueueCount()
{
    return this->nQueueCount;
}

int Station::GetFlags() const
{
    return this->m_fuelFlag;
}

void Station::SetFlags(int nFlags)
{
    this->m_fuelFlag = nFlags;
}

void Station::Start(int nFlags)
{
    static size_t s_nCount = 0;

    pid_t pid = fork();

    switch (pid)
    {
        case -1:
        {
            std::cout << "Ошибка запуска колонки : " << errno << std::endl;
            break;
        }
        case 0:
        {
            /** Запуск терминала хранилища */
            execlp("/usr/bin/gnome-terminal", "gnome-terminal", "--", Station::ms_sStationTerminalPath.c_str(), NULL);

            std::cout << "Ошибка запуска колонки : " << errno << std::endl;
            exit(0);
        }
        default:
        {
            usleep(1000);
            /** Получние нового ID процесса колонки (Изменился после запуска через терминал) */
            pid_t new_pid = 0;
            int fd_init = open(STATION_INIT_PIPE, O_RDONLY);
            if(fd_init == -1)
            {
                fd_init = open(STATION_INIT_PIPE, O_RDONLY);
            }
            ssize_t nCount = read(fd_init, &new_pid, sizeof(pid_t));
            close(fd_init);
            if(nCount != sizeof(pid_t))
            {
                std::cout << "Ошибка инициализации колонки" << std::endl;
                return;
            }
            m_pid = new_pid;

            /** Формирование названия канала */
            std::string sPid = std::to_string(m_pid);
            m_sPipeName = "/tmp/station__pipe" + sPid;
            m_fuelFlag = nFlags;

            StationInitPacket initPacket;
            initPacket.m_nFuelTypeFlags = nFlags;
            initPacket.m_nNumber = s_nCount++;

            /** Отправление колонке пакета инициализации */
            int fd = open(m_sPipeName.c_str(), O_WRONLY);
            write(fd, &initPacket, sizeof(StationInitPacket));
            close(fd);

            break;
        }
    }
}
