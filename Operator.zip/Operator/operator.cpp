#include "operator.h"

std::string EFuelToString(const EFuel& fuelType)
{
    switch (fuelType)
    {
    case EFuel::Diesel:
        return "Дизель";
    case EFuel::GAS:
        return "Газ";
    case EFuel::AI_92:
        return "АИ-92";
    case EFuel::AI_95:
        return "АИ-95";
    case EFuel::AI_98:
        return "АИ-98";
    case EFuel::AI_100:
        return "АИ-100";
    default:
        return std::string();
    }
}

EFuel StringToEFuel(const std::string& sType)
{
    if(sType == "Дизель")
    {
        return EFuel::Diesel;
    }
    if(sType == "Газ")
    {
        return EFuel::GAS;
    }
    if(sType == "АИ-92")
    {
        return EFuel::AI_92;
    }
    if(sType == "АИ-95")
    {
        return EFuel::AI_95;
    }
    if(sType == "АИ-98")
    {
        return EFuel::AI_98;
    }
    if(sType == "АИ-100")
    {
        return EFuel::AI_100;
    }

    return EFuel::UNDEFINED;
}

void Operator::SplitToken(const std::string& str, std::vector<std::string>& vec)
{
    std::stringstream ss(str);
    std::string token;

    while (std::getline(ss, token, ' '))
    {
        vec.push_back(token);
    }
}

unsigned int Operator::Hash(const char* str, int h)
{
    return !str[h] ? 5381 : (Operator::Hash(str, h + 1) * 33) ^ str[h];
}

Operator::Operator()
{
    m_state = 0;

    Storage::ms_sStorageTerminalPath = "/home/nika/Рабочий стол/vc/build-Storage-Desktop-Debug/Storage";
    Station::ms_sStationTerminalPath = "/home/nika/Рабочий стол/vc/build-GasStation-Desktop-Debug/GasStation";

    /** Канал для инициализации колонок */
    mkfifo(STATION_INIT_PIPE, 0666);

    /** Канал приема от колонок */
    mkfifo(OPERATOR_TO_STORAGE_MEDIATOR, 0666);

    pthread_mutex_init(&m_vecLock, nullptr);
    pthread_mutex_init(&m_sendLock, nullptr);

    m_isWork = true;
}

void* Operator::Rountine(void *arg)
{
    Operator *oper = reinterpret_cast<Operator *>(arg);

    /** Прием ответов от колонок */
    while(oper->m_isWork)
    {
        StationPacket packet;

        int fd = open(OPERATOR_TO_STORAGE_MEDIATOR, O_RDONLY);
        ssize_t nCount = read(fd, &packet, sizeof(StationPacket));
        close(fd);

        if(!oper->m_isWork)
        {
            break;
        }

        if(nCount != sizeof(StationPacket))
        {
            continue;
        }

        switch(packet.n_isSuccess)
        {
            case ERROR_NOT_ENOUGH:
                std::cout << "Не хватает топлива типа " << EFuelToString(packet.m_eFuelType) << std::endl;
                break;
            case ERROR_NO_THIS_TYPE:
                std::cout << "В хранилище нет бензина запрошенного типа : " << EFuelToString(packet.m_eFuelType) << std::endl;
                break;
            case SUCCESS_HANDLING:
            {
                std::stringstream ss;
                ss << "[КОЛОНКА:" << packet.m_nNumber + 1 << "] Успешно" << std::endl;
                ss << "В хранилище осталось " << packet.m_nLeft << " единиц топлива " << EFuelToString(packet.m_eFuelType);
                Operator::Log(ss.str());
                break;
            }
            /** Пакет пришел от машины */
            default:
                oper->FillUp(packet.m_nFuelAmount, packet.m_eFuelType);
                break;
        }

        pthread_mutex_lock(&oper->m_vecLock);

        --oper->m_vStations[packet.m_nNumber].GetQueueCount();

        pthread_mutex_unlock(&oper->m_vecLock);
    }

    return nullptr;
}

void Operator::FillUp(size_t nFuelCount, EFuel fuelType)
{
    if(m_state & SystemState::Paused)
    {
        std::cout << "Оператор приостановлен" << std::endl;
        return;
    }

    pthread_mutex_lock(&m_vecLock);

    /** Поиск колонки с заданным видом топлива и минимальной очередью */
    size_t idx = 0;
    size_t queueAmount = 0xFFFFFFFF;
    for(size_t i = 0;i < m_vStations.size();i++)
    {
        size_t qC = m_vStations[i].GetQueueCount();
        if((m_vStations[i].GetFlags() & fuelType) && qC < queueAmount)
        {
            idx = i;
            queueAmount = qC;
        }
    }

    if(queueAmount == 0xFFFFFFFF)
    {
        pthread_mutex_unlock(&m_vecLock);

        std::cout << "Нет колонки с таким топливом" << std::endl;
        return;
    }

    ++m_vStations[idx].GetQueueCount();
    std::string sPipe = m_vStations[idx].GetPipeName();

    pthread_mutex_unlock(&m_vecLock);

    std::stringstream ss;
    ss << "Выбрана колонка №" << idx + 1;
    Operator::Log(ss.str());

    StationPacket packet;
    packet.m_eFuelType = fuelType;
    packet.m_nNumber = idx;
    packet.m_nFuelAmount = nFuelCount;

    pthread_mutex_lock(&m_sendLock);

    int fd = open(sPipe.c_str(), O_WRONLY);
    write(fd,  &packet, sizeof(StationPacket));
    close(fd);

    pthread_mutex_unlock(&m_sendLock);
}


void Operator::Start()
{
    sleep(1);
    pthread_create(&m_thread, nullptr, Operator::Rountine, this);
}

void Operator::ExecuteCommand(const std::string& sCommand)
{
    std::vector<std::string> vParams;
    Operator::SplitToken(sCommand, vParams);

    switch (Operator::Hash(vParams[0].c_str()))
    {
        case COMMAND_HELP:
        {
            std::cout << "help - помощь" << std::endl;
            std::cout << "start_storage - запустить хранилище" << std::endl;
            std::cout << "start_station тип1 - запустить колонку" << std::endl;
            std::cout << "fill_up тип количество - отпустить топливо" << std::endl;
            std::cout << "pause - приостановить работу" << std::endl;
            std::cout << "resume - восстановить работу" << std::endl;
            std::cout << "modify колонка тип1 ... - изменить колонку" << std::endl;
            break;
        }
        case COMMAND_START_STORAGE:
        {
           if(m_state & static_cast<int>(SystemState::StorageRunning))
           {
               std::cout << "Хранилище уже запущено" << std::endl;
               return;
           }

            m_storage.Start();

            m_state = m_state | static_cast<int>(SystemState::StorageRunning);

            break;
        }
        case COMMAND_START_STATION:
        {
            if(vParams.size() < 2)
            {
                std::cout << "Колонка должна поддерживать хотя один вид топлива" << std::endl;
                return;
            }

            Station station;
            int nFlags = 0x00000000;
            for(size_t i = 1;i < vParams.size();i++)
            {
                int nFlag = static_cast<int>(StringToEFuel(vParams[i]));
                if(nFlag == EFuel::UNDEFINED)
                {
                    std::cout << "Неверный тип топлива " << vParams[i];
                    return;
                }

                nFlags = nFlags | nFlag;
            }

            station.Start(nFlags);

            m_vStations.push_back(station);

            m_state = m_state | static_cast<int>(SystemState::StationRunning);

            break;
        }
        case COMMAND_FILL_UP:
        {
            if(m_state & SystemState::Paused)
            {
                std::cout << "Оператор приостановлен" << std::endl;
                return;
            }

            if(m_state != SystemState::ReadyForRequests)
            {
                std::cout << "Должно быть запущено хранилище и хотя бы одна колонка" << std::endl;
                return;
            }

            if(vParams.size() != 3)
            {
                std::cout << "Недостаточно параметров" << std::endl;
                return;
            }

            size_t nFuelAmount = 0;
            EFuel fuelType = EFuel::UNDEFINED;

            try
            {
                nFuelAmount = std::stoul(vParams[2]);
            }
            catch (std::exception ex)
            {
                std::cout << "Неверные параметры" << std::endl;
                return;
            }

            fuelType = StringToEFuel(vParams[1]);
            if(fuelType == EFuel::UNDEFINED)
            {
                std::cout << "Неверные параметры" << std::endl;
                return;
            }

            FillUp(nFuelAmount, fuelType);

            break;
        }
        case COMMAND_PAUSE:
        {
            Pause();
            break;
        }
        case COMMAND_RESUME:
        {
            Resume();
            break;
        }
        case COMMAND_MODIFY:
        {
            if(vParams.size() < 3)
            {
                std::cout << "Недостаточно параметров" << std::endl;
                return;
            }

            size_t nIdx;


            try
            {
                nIdx = std::stoul(vParams[1]) - 1;
                if(nIdx < 0 || nIdx >= m_vStations.size())
                {
                    throw;
                }
            }
            catch (std::exception)
            {
                std::cout << "Неверно указан номер колонки" << std::endl;
                return;
            }

            int nFlags = 0x00000000;
            for(size_t i = 2;i < vParams.size();i++)
            {
                int nFlag = static_cast<int>(StringToEFuel(vParams[i]));
                if(nFlag == EFuel::UNDEFINED)
                {
                    std::cout << "Неверный тип топлива " << vParams[i];
                    return;
                }

                nFlags = nFlags | nFlag;
            }

            pthread_mutex_lock(&m_vecLock);

            std::string sPipeName = m_vStations[nIdx].GetPipeName();
            m_vStations[nIdx].SetFlags(nFlags);

            pthread_mutex_unlock(&m_vecLock);

            StationInitPacket initPacket;
            initPacket.m_nFuelTypeFlags = nFlags;
            initPacket.m_nNumber = nIdx;

            pthread_mutex_lock(&m_sendLock);

            /** Отправление колонке пакета инициализации */
            int fd = open(sPipeName.c_str(), O_WRONLY);
            write(fd, &initPacket, sizeof(StationInitPacket));
            close(fd);

            pthread_mutex_unlock(&m_sendLock);

            break;
        }
        case COMMAND_FAKE_STATIONS:
        {
            Station station_1;
            station_1.Start(EFuel::Diesel | EFuel::GAS);

            Station station_2;
            station_2.Start(EFuel::AI_100);

            Station station_3;
            station_3.Start(EFuel::AI_92 | EFuel::AI_95 | EFuel::AI_98);

            m_vStations.push_back(station_1);
            m_vStations.push_back(station_2);
            m_vStations.push_back(station_3);

            m_state = m_state | static_cast<int>(SystemState::StationRunning);

            break;
        }
        default:
        {
            std::cout << "Неизвестная команда" << std::endl;
            break;
        }
    }
}

void Operator::Pause()
{
    if(m_state & SystemState::Paused)
    {
        std::cout << "Оператор уже остановлен" << std::endl;
        return;
    }
    m_state = m_state | SystemState::Paused;
}

void Operator::Resume()
{
    if(!(m_state & SystemState::Paused))
    {
        std::cout << "Оператор итак работает" << std::endl;
        return;
    }
    m_state = m_state & ~SystemState::Paused;
}

Operator::~Operator()
{
    m_isWork = false;

    pthread_join(m_thread, nullptr);

    pthread_mutex_destroy(&m_vecLock);
    pthread_mutex_destroy(&m_sendLock);
}

void Operator::Log(const std::string& text)
{
    std::cout << "\033[1;33m" << text << "\033[0m" << std::endl;
}
