#include "storage.h"

std::string Storage::ms_sStorageTerminalPath;

Storage::Storage()
{

}


void Storage::Start()
{
    pid_t pid = fork();

    switch (pid)
    {
        case -1:
        {
            std::cout << "Ошибка запуска хранилища : " << errno << std::endl;
            break;
        }
        case 0:
        {
            /** Запуск терминала хранилища */
            execlp("/usr/bin/gnome-terminal", "gnome-terminal", "--", Storage::ms_sStorageTerminalPath.c_str(), NULL);

            std::cout << "Ошибка запуска хранилища : " << errno << std::endl;
            exit(0);
        }
        default:
        {
            m_pid = pid;

            break;
        }
    }
}
