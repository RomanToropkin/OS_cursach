#ifndef OPERATOR_H
#define OPERATOR_H

#include "station.h"
#include "storage.h"

/** Канал получения ответов от колонок */
#define OPERATOR_TO_STORAGE_MEDIATOR  "/tmp/storage__operator"

/** Хэши команд */
#define COMMAND_HELP          0x7C75DEB4
#define COMMAND_START_STORAGE 0x04B73663
#define COMMAND_START_STATION 0x8544C7E0
#define COMMAND_FAKE_STATIONS 0x3462459A
#define COMMAND_FILL_UP       0x68823DF0
#define COMMAND_PAUSE         0x09E1DA57
#define COMMAND_RESUME        0x45774DFC
#define COMMAND_MODIFY        0x85896FF5

/** Мусорное значение пакета */
#define BUMP_VALUE 0xFFFFFFFFFFFFFFFF

/** Состояние системы */
enum SystemState
{
    /** Запущена */
    Started = 0,
    /** Хранилище запущено */
    StorageRunning = 1 << 0,
    /** Запущена хотя бы одна колонка */
    StationRunning = 1 << 1,
    /** Приостановлен */
    Paused = 1 << 2,
    /** Запущена хотя бы одна колонка и хранилище (Готова для запросов пользователей) */
    ReadyForRequests = SystemState::StorageRunning | SystemState::StationRunning
};

std::string EFuelToString(const EFuel& fuelType);

EFuel StringToEFuel(const std::string& sType);

class Operator
{
private:
    /** Хранилище */
    Storage m_storage;

    /** Вектор колонок */
    std::vector<Station> m_vStations;

    /** Состояние */
    int m_state;

    /** Поток приема ответов от колонок */
    pthread_t m_thread;

    /** Мьютекс для синхронизации вектора колонок */
    pthread_mutex_t m_vecLock;

    /** Мьютекс для синхронизации отправки заявок на колонки */
    pthread_mutex_t m_sendLock;

    /** Флаг работы */
    bool m_isWork;

private:
    /** Хэшировать строку для switch'a */
    static unsigned int Hash(const char* str, int h = 0);

    /** Разбить строку на токены */
    static void SplitToken(const std::string& str, std::vector<std::string>& vec);

    /** Обработчик потока */
    static void* Rountine(void *arg);

    static void Log(const std::string& text);

public:
    Operator();

    /** Выполнить команду */
    void ExecuteCommand(const std::string& sCommand);

    /** Заправить машину */
    void FillUp(size_t nFuelCount, EFuel fuelType);

    /** Начать работу оператора */
    void Start();

    /** Приостановить */
    void Pause();

    /** Возобновить */
    void Resume();

    ~Operator();
};

#endif // OPERATOR_H
