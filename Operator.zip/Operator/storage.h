#ifndef STORAGE_H
#define STORAGE_H

#include "global.h"

#define ERROR_NO_THIS_TYPE  0x000000FF
#define ERROR_NOT_ENOUGH    0x0000FFFF
#define SUCCESS_HANDLING    0x00FFFFFF

class Storage
{
private:
    /** ID процесса */
    pid_t m_pid;

    /** Дескриптор канала Хранилище читает - Оператор пишет */
    int m_fd;

public:
    /** Путь до исполняемого файла (Терминал хранилища) */
    static std::string ms_sStorageTerminalPath;

public:
    Storage();

    /** Запустить хранилище */
    void Start();
};

#endif // STORAGE_H
