#ifndef TANK_H
#define TANK_H

#include "global.h"

#define ERROR_NO_THIS_TYPE  0x000000FF
#define ERROR_NOT_ENOUGH    0x0000FFFF
#define SUCCESS_HANDLING    0x00FFFFFF

/** Тип топлива */
enum EFuel : int
{
    /** Солярка */
    Diesel = 1 << 0,
    /** Газ */
    GAS = 1 << 1,
    /** 92 бензин */
    AI_92 = 1 << 2,
    /** 95 бензин */
    AI_95 = 1 << 3,
    /** 98 бензин */
    AI_98 = 1 << 4,
    /** 100 бензин */
    AI_100 = 1 << 5
};

std::string EFuelToString(const EFuel& fuelType);

EFuel StringToEFuel(const std::string& sType);


struct TankPacket
{
    /** Тип топлива */
    EFuel m_fuelType;
    /** Название канала колонки */
    char m_pipeName[255];
    union
    {
        /** Запрошено топлива */
        size_t m_nRequested;
        struct
        {
            /** Осталось топлива */
            int m_nLeft;
            /** Успешно ли ? */
            int n_isSuccess;
        };
    };
};


/** Класс бак */
class Tank
{
private:
    /** Тип топлива */
    EFuel m_eFuelType;

    /** Текущий объем */
    size_t m_nVolume;
    /** Нижняя граница */
    size_t m_nLowerBound;
    /** Верхняя граница */
    size_t m_nUpperBound;

    /** Callback на завершение */
    std::function<void(const TankPacket&)> done;

    /** Поток приема и обработки запросов */
    pthread_t m_thread;

    /** Флаг работы бака */
    bool m_isWork;

    /** Флаг приостаоновки работы бака */
    bool m_isPaused;

    /** Очередь запросов на выкачивание */
    std::queue<TankPacket> m_vReqQueue;

    /** Событие на добавление заявки в очередь */
    int m_eventRequest;

    /** Мьютекс для синхронизации изменения текущего объема */
    pthread_mutex_t m_volumeLock;

    /** Мьютекс для синхронизации работы с очередью запросов */
    pthread_mutex_t m_queueLock;

public:
    Tank();

    Tank(size_t nLowerBound, size_t nUpperBound, const EFuel& fuelType, std::function<void(const TankPacket&)> done);

    /** Наполнить */
    void FillUp();

    /** Выкачать топливо */
    void PumpOutFuel(const TankPacket &recv_packet);

    /** Добавить запрос на выкачивание в очередь */
    void AddRequest(const TankPacket& packet);

    /** Обработчик потока */
    static void* Rountine(void *arg);

    /** Запуск работы бака */
    void Start();

    /** Приостановить работу бака,
     * например, если его объем исчерпан */
    void Pause();

    /** Возобновить работу */
    void Resume();

    /** Приостановлена ли работа бака ? */
    bool IsPaused() const;

    /** Получить тип топлива в баке */
    EFuel GetFuelType() const;

    /** Завершение работы бака */
    void Stop();

    /** Вывести информацию о баке в stdout */
    void Print() const;

/** Сеттеры */
public:
    void SetLowerBound(size_t nValue);

    void SetUpperBound(size_t nValue);

    void SetFuelType(EFuel nValue);

};

#endif // TANK_H
