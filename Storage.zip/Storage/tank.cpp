#include "tank.h"

std::string EFuelToString(const EFuel& fuelType)
{
    switch (fuelType)
    {
    case EFuel::Diesel:
        return "Дизель";
    case EFuel::GAS:
        return "Газ";
    case EFuel::AI_92:
        return "АИ-92";
    case EFuel::AI_95:
        return "АИ-95";
    case EFuel::AI_98:
        return "АИ-98";
    case EFuel::AI_100:
        return "АИ-100";
    }
    return std::string();
}

EFuel StringToEFuel(const std::string& sType)
{
    if(sType == "Дизель")
    {
        return EFuel::Diesel;
    }
    if(sType == "Газ")
    {
        return EFuel::GAS;
    }
    if(sType == "АИ-92")
    {
        return EFuel::AI_92;
    }
    if(sType == "АИ-95")
    {
        return EFuel::AI_95;
    }
    if(sType == "АИ-98")
    {
        return EFuel::AI_98;
    }
    if(sType == "АИ-100")
    {
        return EFuel::AI_100;
    }

    throw std::exception();
}

Tank::Tank()
{

}

Tank::Tank(size_t nLowerBound, size_t nUpperBound, const EFuel& fuelType, std::function<void(const TankPacket&)> done)
{
    this->m_eFuelType = fuelType;

    this->m_nVolume = 0;

    this->m_nLowerBound = nLowerBound;
    this->m_nUpperBound = nUpperBound;

    this->done = done;
}

void Tank::FillUp()
{
    pthread_mutex_lock(&m_volumeLock);
    m_nVolume = m_nUpperBound;

    m_isPaused = false;
    pthread_mutex_unlock(&m_volumeLock);
}

void Tank::AddRequest(const TankPacket& packet)
{
    if(m_isPaused)
    {
        return;
    }

    pthread_mutex_lock(&m_queueLock);
    m_vReqQueue.push(packet);
    pthread_mutex_unlock(&m_queueLock);

    /** Запись в дескриптор события о том, что в очередь поступила заявка и можно разлочиться */
    uint64_t value = 1;
    write(m_eventRequest, &value, sizeof(value));
}

void Tank::PumpOutFuel(const TankPacket& recv_packet)
{
    size_t nVol = recv_packet.m_nRequested;

    TankPacket packet;
    packet.m_fuelType = this->m_eFuelType;
    strcpy(packet.m_pipeName, recv_packet.m_pipeName);

    long long int nDiff = static_cast<long long int>(m_nVolume) - static_cast<long long int>(nVol);
    /** Если не хватает топлива */
    if(nDiff < static_cast<long long int>(m_nLowerBound))
    {
        packet.m_nLeft = static_cast<int>(m_nVolume - nVol);
        packet.n_isSuccess = ERROR_NOT_ENOUGH;

        /** Приостановить работу бака */
        Pause();

        goto CALLBACK;
    }

    if(nDiff == static_cast<long long int>(m_nLowerBound))
    {
        Pause();
    }

    pthread_mutex_lock(&m_volumeLock);
    this->m_nVolume -= nVol;
    pthread_mutex_unlock(&m_volumeLock);

    packet.m_nLeft = static_cast<int>(m_nVolume - nVol);
    packet.n_isSuccess = SUCCESS_HANDLING;

    /** Возврат управления контексту хранилища */
    CALLBACK:
    if(done)
    {
        done(packet);
    }
}

void* Tank::Rountine(void *arg)
{
    Tank *tank = static_cast<Tank *>(arg);

    /** Цикл обработки запросов */
    while(tank->m_isWork)
    {
        pthread_mutex_lock(&tank->m_queueLock);
        /** Ожидание поступления заявок в очередь */
        while(tank->m_vReqQueue.empty() && tank->m_isWork)
        {
            pthread_mutex_unlock(&tank->m_queueLock);

            uint64_t value;
            read(tank->m_eventRequest, &value, sizeof(value));

            pthread_mutex_lock(&tank->m_queueLock);
        }
        pthread_mutex_unlock(&tank->m_queueLock);

        if(!tank->m_isWork)
        {
            break;
        }

        /** Получение заявки */
        pthread_mutex_lock(&tank->m_queueLock);
        TankPacket packet = tank->m_vReqQueue.front();
        tank->m_vReqQueue.pop();
        pthread_mutex_unlock(&tank->m_queueLock);

        /** Выполнить заявку */
        tank->PumpOutFuel(packet);
    }

    return nullptr;
}


void Tank::Start()
{
    m_isWork = true;
    m_isPaused = true;
    m_eventRequest = 0;

    m_eventRequest = eventfd(0, 0);
    pthread_mutex_init(&m_volumeLock, nullptr);
    pthread_mutex_init(&m_queueLock, nullptr);

    pthread_create(&m_thread, nullptr, Tank::Rountine, this);
}

void Tank::Pause()
{
    m_isPaused = true;
}

void Tank::Resume()
{
    m_isPaused = false;
}

bool Tank::IsPaused() const
{
    return this->m_isPaused;
}

EFuel Tank::GetFuelType() const
{
    return this->m_eFuelType;
}


void Tank::Stop()
{
    m_isWork = false;

    uint64_t value = 1;
    write(m_eventRequest, &value, sizeof(value));

    pthread_join(m_thread, nullptr);

    close(m_eventRequest);

    pthread_mutex_destroy(&m_volumeLock);
    pthread_mutex_destroy(&m_queueLock);
}

void Tank::Print() const
{
    std::cout << m_nVolume << "\t" << m_nLowerBound << "\t" << m_nUpperBound << "\t" << EFuelToString(m_eFuelType) << "\t";
    if(m_isPaused)
    {
        std::cout << "\033[1;31mPAUSED\033[0m";
    }
    else
    {
        std::cout << "\033[1;32mWORKS\033[0m";
    }
    std::cout << std::endl;
}

void Tank::SetLowerBound(size_t nValue)
{
    this->m_nLowerBound = nValue;
}

void Tank::SetUpperBound(size_t nValue)
{
    this->m_nUpperBound = nValue;
}

void Tank::SetFuelType(EFuel nValue)
{
    this->m_eFuelType = nValue;
}
