#include <iostream>

#include "storage.h"

int main()
{
    std::cout << "Хранилище" << std::endl;

    Storage storage;

    storage.Listen();

    /** Пока хранилище работает */
    while(storage.GetState())
    {
        std::string sCommand;
        try
        {
            std::getline(std::cin, sCommand);
        }
        catch (std::exception ex)
        {
            break;
        }

        if(sCommand == "exit")
        {
            break;
        }

        storage.ExecuteCommand(sCommand);
    }

    if(storage.GetState())
    {
        storage.Stop();
    }

    return 0;
}
