#pragma once

#ifndef STORAGE_H
#define STORAGE_H

#include "global.h"

#include "tank.h"

#define STORAGE_PIPE_PATH "/tmp/storage__pipe"

/** Хэши команд */
#define COMMAND_HELP     0x7C75DEB4
#define COMMAND_ADD_TANK 0x0B871E44
#define COMMAND_FILL     0x7C6F28AA
#define COMMAND_PRINT    0x0AEC7A54
#define COMMAND_PAUSE    0x09E1DA57
#define COMMAND_KILL     0x7C6F28A7
#define COMMAND_FAKE     0x7C6B90CC
#define COMMAND_RESUME   0x45774DFC
#define COMMAND_MODIFY   0x85896FF5
#define COMMAND_EXIT     0x7C73BE85

/** Класс хранилище */
class Storage
{
private:
    /** Вектор баков */
    std::vector<Tank*> m_vTanks;

    /** Дескриптор канала */
    int m_fd;

    /** Поток получения запросов */
    pthread_t m_thread;

    /** Мьютекс для синхронизации работы с вектором баков */
    pthread_mutex_t m_vecLock;

    /** Мьютекс для синхронизации отправки */
    pthread_mutex_t m_sendLock;

    /** Флаг работы хранилища */
    bool m_isWork;

private:
    /** Разбить строку на токены */
    static void SplitToken(const std::string& str, std::vector<std::string>& vec);

    /** Хэшировать строку для switch'a */
    static unsigned int Hash(const char* str, int h = 0);

    /** Обработчик потока */
    static void* Rountine(void *arg);

public:
    Storage();

    /** Начать прослушивание */
    void Listen();

    /** Послать команду */
    void ExecuteCommand(const std::string &sCommand);

    /** Остановить работу хранилища */
    void Stop();

    /** Получить состояние хранилища */
    bool GetState() const;

private:

    /** Добавить бак */
    void AddTank(const std::string &sCommand);

    /** Вывести информацию о баках */
    void Print();

    /** Получить параметр из команды с одиним параметром */
    size_t GetSingleParameter(const std::string &sCommand, size_t pos, size_t count = ULONG_MAX);

private:
    /** Вывести лог (Желтый цвет) */
    static void Log(const std::string& text);
};

#endif // STORAGE_H
