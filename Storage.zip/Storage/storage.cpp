#include "storage.h"

void Storage::SplitToken(const std::string& str, std::vector<std::string>& vec)
{
    std::stringstream ss(str);
    std::string token;

    while (std::getline(ss, token, ' '))
    {
        vec.push_back(token);
    }
}

size_t Storage::GetSingleParameter(const std::string &sCommand, size_t pos, size_t count)
{
    std::string sIdx = sCommand.substr(pos + 1, sCommand.length() - pos - 1);
    size_t idx = 0;

    try
    {
        idx = std::stoi(sIdx);
    }
    catch(std::exception ex)
    {
        std::cout << "Указан неверный индекс" << std::endl;
        return -1;
    }

    if(idx > count)
    {
        std::cout << "Указан неверный индекс" << std::endl;
        return -1;
    }

    return idx;
}

Storage::Storage()
{

}

unsigned int Storage::Hash(const char* str, int h)
{
    return !str[h] ? 5381 : (Storage::Hash(str, h + 1) * 33) ^ str[h];
}

void Storage::Listen()
{
    m_isWork = true;

    pthread_mutex_init(&m_sendLock, nullptr);
    pthread_mutex_init(&m_vecLock, nullptr);

    /** Создание канала Колонка пишет - Хранилище читает */
    mkfifo(STORAGE_PIPE_PATH, 0666);

    /** Запуск потока прослушивания */
    pthread_create(&m_thread, nullptr, Storage::Rountine, this);
}

void* Storage::Rountine(void *arg)
{
    Storage *storage = reinterpret_cast<Storage *>(arg);

    while(storage->m_isWork)
    {
        TankPacket packet;

        /** Получение пакета от колонки по каналу */
        storage->m_fd = open(STORAGE_PIPE_PATH, O_RDONLY);
        ssize_t nCount = read(storage->m_fd, &packet, sizeof(TankPacket));

        if(!storage->m_isWork)
        {
            close(storage->m_fd);
            return nullptr;
        }

        if(nCount != sizeof(TankPacket))
        {
            close(storage->m_fd);
            continue;
        }

        close(storage->m_fd);

        std::stringstream stream;
        stream << "Запрошено " << packet.m_nRequested << " единицы топлива " << EFuelToString(packet.m_fuelType);
        Storage::Log(stream.str());

        pthread_mutex_lock(&storage->m_vecLock);
        /** Выбор запущенного бака с нужным типом топлива */
        EFuel fuelType = packet.m_fuelType;
        for(size_t i = 0;i < storage->m_vTanks.size();i++)
        {
            if(!storage->m_vTanks[i]->IsPaused() && storage->m_vTanks[i]->GetFuelType() == fuelType)
            {
                std::stringstream lstream;
                lstream << "Для подачи топлива выбран бак №" << i + 1;
                Storage::Log(lstream.str());

                storage->m_vTanks[i]->AddRequest(packet);

                pthread_mutex_unlock(&storage->m_vecLock);
                goto SELECTED;
            }
        }

        {
            pthread_mutex_unlock(&storage->m_vecLock);

            TankPacket error_packet;
            memset(&error_packet, 0, sizeof(TankPacket));
            error_packet.n_isSuccess = ERROR_NO_THIS_TYPE;

            pthread_mutex_lock(&storage->m_sendLock);

            /** Открытие канала для записи клиенту  */
            int fd = open(packet.m_pipeName, O_WRONLY);
            /** Ответ панели о том, что судно прошло шлюз */
            write(fd, &error_packet, sizeof(TankPacket));

            close(fd);

            pthread_mutex_unlock(&storage->m_sendLock);


            std::stringstream lstream;
            lstream << "Сейчас нет доступных баков с топливом типа " << EFuelToString(fuelType);
            Storage::Log(lstream.str());

            continue;
        }

        SELECTED:
        NULL;
    }

    return nullptr;
}

void Storage::ExecuteCommand(const std::string &sCommand)
{
    std::string replCommand = sCommand;

    size_t pos = sCommand.find(" ");
    if(pos != std::string::npos)
    {
        replCommand = sCommand.substr(0, pos);
    }

    switch(Storage::Hash(replCommand.c_str()))
    {
        case COMMAND_HELP:
        {
            std::cout << "help - помощь" << std::endl;
            std::cout << "add lowerbound upperbound fueltype - добавление бака" << std::endl;
            std::cout << "print - вывести информацию о баках" << std::endl;
            std::cout << "fill id - заполнить бак *id*" << std::endl;
            std::cout << "pause id - приостановить бак *id*" << std::endl;
            std::cout << "kill id - удалить бак *id*" << std::endl;
            break;
        }
        case COMMAND_ADD_TANK:
        {
            AddTank(sCommand);
            break;
        }
        case COMMAND_PRINT:
        {
            Print();
            break;
        }
        case COMMAND_FILL:
        {
            size_t p = GetSingleParameter(sCommand, pos, m_vTanks.size()) - 1;
            if(p == ULONG_MAX)
            {
                return;
            }

            /** Заполняем бак с индексом */
            pthread_mutex_lock(&m_vecLock);
            m_vTanks[p]->FillUp();
            pthread_mutex_unlock(&m_vecLock);

            break;
        }
        case COMMAND_PAUSE:
        {
            size_t p = GetSingleParameter(sCommand, pos, m_vTanks.size()) - 1;
            if(p == ULONG_MAX)
            {
                return;
            }

            /** Приостанавливаем бак с индексом */
            pthread_mutex_lock(&m_vecLock);
            if(m_vTanks[p]->IsPaused())
            {
                std::cout << "Бак " << p << " уже остановлен" << std::endl;

                pthread_mutex_unlock(&m_vecLock);
                return;
            }

            m_vTanks[p]->Pause();
            pthread_mutex_unlock(&m_vecLock);

            break;
        }
        case COMMAND_RESUME:
        {
            size_t p = GetSingleParameter(sCommand, pos, m_vTanks.size()) - 1;
            if(p == ULONG_MAX)
            {
                return;
            }

            /** Приостанавливаем бак с индексом */
            pthread_mutex_lock(&m_vecLock);
            if(!m_vTanks[p]->IsPaused())
            {
                std::cout << "Бак " << p << " работает" << std::endl;

                pthread_mutex_unlock(&m_vecLock);
                return;
            }

            m_vTanks[p]->Resume();
            pthread_mutex_unlock(&m_vecLock);

            break;
        }
        case COMMAND_KILL:
        {
            size_t p = GetSingleParameter(sCommand, pos, m_vTanks.size()) - 1;
            if(p == size_t(-1))
            {
                return;
            }

            /** Удаляем бак с индексом */
            pthread_mutex_lock(&m_vecLock);

            m_vTanks[p]->Stop();
            m_vTanks.erase(m_vTanks.begin() + p);

            pthread_mutex_unlock(&m_vecLock);

            break;
        }
        case COMMAND_MODIFY:
        {
            std::vector<std::string> vTokens;
            SplitToken(sCommand, vTokens);

            if(vTokens.size() != 5)
            {
                std::cout << "Недостаточно параметров" << std::endl;
                return;
            }

            size_t nIdx = 0;
            size_t nLowerBound = 0;
            size_t nUpperBound = 0;
            EFuel fuelType;

            try
            {
                nIdx = std::stoul(vTokens[1]);
                nLowerBound = std::stoul(vTokens[2]);
                nUpperBound = std::stoul(vTokens[3]);
                fuelType = StringToEFuel(vTokens[4]);

                if(nIdx > m_vTanks.size() || nIdx < 1)
                {
                    std::cout << "Бака с таким номером нет" << std::endl;
                    throw;
                }

                if(nLowerBound > nUpperBound)
                {
                    std::swap(nLowerBound, nUpperBound);
                }
            }
            catch (std::exception ex)
            {
                std::cout << "Неверно указаны параметры" << std::endl;
                return;
            }

            nIdx--;

            /** Модифицируем значения */
            pthread_mutex_lock(&m_vecLock);

            m_vTanks[nIdx]->SetFuelType(fuelType);
            m_vTanks[nIdx]->SetLowerBound(nLowerBound);
            m_vTanks[nIdx]->SetUpperBound(nUpperBound);

            m_vTanks[nIdx]->FillUp();

            pthread_mutex_unlock(&m_vecLock);

            break;
        }
        case COMMAND_FAKE:
        {
            AddTank("add 10 100 Дизель");
            AddTank("add 20 40 АИ-92");
            AddTank("add 11 55 Газ");
            AddTank("add 25 111 АИ-95");

            /** Заполняем баки */
            pthread_mutex_lock(&m_vecLock);

            for(size_t i = 0;i < m_vTanks.size();i++)
            {
                m_vTanks[i]->FillUp();
            }

            pthread_mutex_unlock(&m_vecLock);

            break;
        }
        default:
        {
            std::cout << "Неверно указана команда" << std::endl;
            break;
        }
    }
}

void Storage::Stop()
{
    pthread_mutex_lock(&m_vecLock);

    for(size_t i = 0;i < m_vTanks.size();i++)
    {
        m_vTanks[i]->Stop();
        delete m_vTanks[i];
    }

    m_isWork = false;

    pthread_mutex_unlock(&m_vecLock);

    close(m_fd);
    pthread_cancel(m_thread);

    pthread_mutex_destroy(&m_sendLock);
    pthread_mutex_destroy(&m_vecLock);
}

void Storage::AddTank(const std::string &sCommand)
{
    size_t pos = sCommand.find(" ");
    std::string params = sCommand.substr(pos + 1, sCommand.length() - pos);

    pos = params.find(" ");
    if(pos == std::string::npos)
    {
        std::cout << "Должно быть три параметра" << std::endl;
        return;
    }

    std::string sLower = params.substr(0, pos);
    std::string sLeftParams = params.substr(pos + 1, params.length() - pos);

    pos = sLeftParams.find(" ");
    if(pos == std::string::npos)
    {
        std::cout << "Должно быть три параметра" << std::endl;
        return;
    }

    std::string sUpper = sLeftParams.substr(0, pos + 1);
    std::string sType = sLeftParams.substr(pos + 1, sLeftParams.length() - pos);

    size_t nLower = 0;
    size_t nUpper = 0;
    EFuel fuelType = EFuel::Diesel;

    try
    {
        nLower = std::stoi(sLower);
        nUpper = std::stoi(sUpper);
        fuelType = StringToEFuel(sType);
    }
    catch(std::exception ex)
    {
        std::cout << "Некорректные параметры" << std::endl;
        return;
    }

    if(nLower == nUpper)
    {
        std::cout << "Нижняя и верхняя границы не могут быть равны" << std::endl;
        return;
    }

    if(nLower > nUpper)
    {
        std::swap(nLower, nUpper);
    }

    /** Callback, который выполняется потоком бака после выполнения запроса */
    std::function<void(const TankPacket&)> func = [&](const TankPacket& packet) -> void
    {
        pthread_mutex_lock(&m_sendLock);

        /** Открытие канала для записи клиенту  */
        int fd = open(packet.m_pipeName, O_WRONLY);
        /** Ответ панели о том, что судно прошло шлюз */
        write(fd, &packet, sizeof(TankPacket));

        close(fd);

        pthread_mutex_unlock(&m_sendLock);
    };

    /** Добавляем новый бак */
    pthread_mutex_lock(&m_vecLock);

    m_vTanks.push_back(new Tank(nLower, nUpper, fuelType, func));
    m_vTanks[m_vTanks.size() - 1]->Start();

    pthread_mutex_unlock(&m_vecLock);
}

void Storage::Print()
{
    if(m_vTanks.size() == 0)
    {
        std::cout << "Путо" << std::endl;
        return;
    }

    pthread_mutex_lock(&m_vecLock);

    std::cout << "ИД" << "\t" << "Объем" << "\t" << "Мин" << "\t" << "Макс" << "\t" << "Топливо" << "\t" << "Состояние" << std::endl;
    for(size_t i = 0;i < m_vTanks.size();i++)
    {
        std::cout << i + 1 << "\t";
        m_vTanks[i]->Print();
    }

    pthread_mutex_unlock(&m_vecLock);
}

void Storage::Log(const std::string& text)
{
    std::cout << "\033[1;33m" << text << "\033[0m" << std::endl;
}

bool Storage::GetState() const
{
    return this->m_isWork;
}
